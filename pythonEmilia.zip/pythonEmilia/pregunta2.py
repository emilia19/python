
#SUMA
suma = 0

for i in range(1,5):
     
  suma =suma+i

print('la suma del numero 1 hasta el 4 es :',suma)


#multiplicar
lista=[1,2,3,4]

resul=1
for i in lista:
    resul*=i
    print('la multiplicacion es :',resul)
