from django.urls import path
from api import views

urlpatterns =[
    
    path('hello-wiev/', views.hello.as_view()),

   

]
