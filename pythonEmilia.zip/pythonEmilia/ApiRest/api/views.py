from rest_framework.views  import APIView
from rest_framework.response import Response

class hello(APIView):


     def get(self,request,format=None):

         an_apiview=[

             'esto es prueba final de APIREST FULL',
              'esto es prueba  2 final',
              'usamos funciones como get,put ,delete',
         ]


         return Response({'message ':'hello', 'an_apiview':an_apiview})