from django.db import models

# Create your models here.

"""class hora(request):

    hora_actual=models.models.DateTimeField(auto_now=False, auto_now_add=False)"""

